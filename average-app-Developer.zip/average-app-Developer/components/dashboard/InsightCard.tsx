import Ionicons from "@expo/vector-icons/Ionicons";
import { StyleSheet, Text, View } from "react-native";
import { BG, CARD, LIME, MUTED, STROKE, TEXT } from "./theme";

type Props = {
  title: string;
  subtitle: string;
  icon: "pie-chart" | "trending-up";
  progress?: number; // 0..1
};

export default function InsightCard({ title, subtitle, icon, progress }: Props) {
  return (
    <View style={s.cardSmall}>
      <View style={s.cardSmallIcon}>
        <Ionicons name={icon} size={14} color={BG} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={s.smallTitle}>{title}</Text>
        <Text style={s.smallSub}>{subtitle}</Text>

        {typeof progress === "number" && (
          <View style={s.progressTrack}>
            <View style={[s.progressFill, { width: `${Math.round(progress * 100)}%` }]} />
          </View>
        )}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  cardSmall: {
    flex: 1,
    backgroundColor: CARD,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: STROKE,
    padding: 12,
    gap: 8,
  },
  cardSmallIcon: {
    width: 22,
    height: 22,
    borderRadius: 999,
    backgroundColor: LIME,
    alignItems: "center",
    justifyContent: "center",
  },
  smallTitle: { color: TEXT, fontSize: 14, fontWeight: "800" },
  smallSub: { color: MUTED, fontSize: 11, lineHeight: 14 },

  progressTrack: {
    height: 10,
    backgroundColor: "rgba(255,255,255,0.08)",
    borderRadius: 9999,
    overflow: "hidden",
    marginTop: 10,
  },
  progressFill: {
    height: "100%",
    backgroundColor: "#B7FF58",
    borderRadius: 9999,
  },
});
