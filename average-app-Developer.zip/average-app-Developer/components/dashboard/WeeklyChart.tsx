import { StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, PURPLE, STROKE } from "./theme";

type Day = { d: string; v: number };
type Props = { title: string; data: Day[] };

export default function WeeklyChart({ title, data }: Props) {
  const max = Math.max(...data.map((x) => x.v)) || 1;

  return (
    <View style={s.card}>
      <Text style={s.sectionTitle}>{title}</Text>
      <View style={s.barWrap}>
        {data.map((x) => {
          const h = Math.round((x.v / max) * 120);
          return (
            <View key={x.d} style={s.barItem}>
              <View style={[s.bar, { height: h }]} />
              <Text style={s.barLabel}>{x.d}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  card: {
    backgroundColor: CARD,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: STROKE,
    padding: 16,
    marginBottom: 14,
  },
  sectionTitle: { color: MUTED, fontSize: 12, fontWeight: "700", marginBottom: 10 },
  barWrap: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", gap: 12, height: 150 },
  barItem: { alignItems: "center", gap: 6, flex: 1 },
  bar: {
    width: "100%",
    backgroundColor: PURPLE,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    borderWidth: 1,
    borderColor: "#5e47df",
    shadowColor: PURPLE,
    shadowOpacity: 0.4,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  barLabel: { color: MUTED, fontSize: 10, fontWeight: "700" },
});
