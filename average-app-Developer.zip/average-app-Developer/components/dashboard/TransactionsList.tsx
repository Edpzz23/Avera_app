import { StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Item = { name: string; when: string; amt: number };
type Props = { title: string; items: Item[] };

export default function TransactionsList({ title, items }: Props) {
  return (
    <View style={s.listCard}>
      <Text style={s.listTitle}>{title}</Text>
      <View style={{ marginTop: 6 }}>
        {items.map((t, i) => (
          <View key={`${t.name}-${i}`} style={[s.rowTx, i !== items.length - 1 && s.rowDivider]}>
            <View style={{ flex: 1 }}>
              <Text style={s.txName}>{t.name}</Text>
              <Text style={s.txWhen}>{t.when}</Text>
            </View>
            <Text style={[s.txAmt, t.amt >= 0 ? s.amtPos : s.amtNeg]}>
              {t.amt >= 0 ? `+$${t.amt.toLocaleString()}` : `-$${Math.abs(t.amt).toLocaleString()}`
              }
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  listCard: {
    backgroundColor: CARD,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: STROKE,
    padding: 14,
  },
  listTitle: { color: TEXT, fontSize: 16, fontWeight: "800", marginBottom: 8 },
  rowTx: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  rowDivider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: STROKE },
  txName: { color: TEXT, fontSize: 14, fontWeight: "700" },
  txWhen: { color: MUTED, fontSize: 11, marginTop: 2 },
  txAmt: { fontSize: 14, fontWeight: "800", marginLeft: 10 },
  amtPos: { color: "#6DFF7A" },
  amtNeg: { color: "#CBD1DD" },
});
