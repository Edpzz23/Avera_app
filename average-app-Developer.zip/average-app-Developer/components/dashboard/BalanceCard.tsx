import { StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Props = {
  balance: string;
  subtitle: string;
  income: string;
  expenses: string;
};

export default function BalanceCard({ balance, subtitle, income, expenses }: Props) {
  return (
    <View style={s.balance}>
      <Text style={s.balanceMain}>{balance}</Text>
      <Text style={s.balanceSub}>{subtitle}</Text>

      <View style={s.balanceRow}>
        <View style={s.balanceMini}>
          <Text style={s.miniLabel}>Income</Text>
          <Text style={s.miniValue}>{income}</Text>
        </View>
        <View style={s.balanceMini}>
          <Text style={s.miniLabel}>Expenses</Text>
          <Text style={s.miniValue}>{expenses}</Text>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  balance: {
    backgroundColor: CARD,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: STROKE,
    padding: 16,
    gap: 12,
    marginBottom: 14,
  },
  balanceMain: { color: TEXT, fontSize: 34, fontWeight: "800", letterSpacing: 0.2 },
  balanceSub: { color: MUTED, fontSize: 12, fontWeight: "600" },
  balanceRow: { flexDirection: "row", gap: 10 },
  balanceMini: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: "#10131A",
    borderWidth: 1,
    borderColor: STROKE,
    alignItems: "center",
    gap: 4,
  },
  miniLabel: { color: MUTED, fontSize: 11, fontWeight: "600" },
  miniValue: { color: TEXT, fontSize: 14, fontWeight: "700" },
});
