import Ionicons from "@expo/vector-icons/Ionicons";
import { useRouter } from "expo-router";
import { Image, Pressable, StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

export default function DashboardHeader() {
  const router = useRouter();

  return (
    <View style={s.header}>
      <View style={s.brand}>
        <Image
          source={require("@/assets/images/LogoAverage.png")}
          style={s.logo}
          resizeMode="contain"
        />
        <Text style={s.brandTxt}>Average</Text>
      </View>

      <View style={s.headerRight}>
        <Pressable
          style={s.chip}
          android_ripple={{ color: "#22262F", borderless: false }}
        >
          <Text style={s.chipTxt}>This Week</Text>
          <Ionicons name="chevron-down" size={16} color={MUTED} />
        </Pressable>

        <Pressable
          onPress={() => router.push("/(tabs)/filters")}
          hitSlop={10}
          style={s.iconBtn}
          android_ripple={{ color: "#22262F", borderless: true }}
        >
          <Ionicons name="funnel-outline" size={20} color={MUTED} />
          {/* alternativa si quieres “gráfica”: name="stats-chart" */}
        </Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingTop: 6,
    marginBottom: 8,
  },
  brand: { flexDirection: "row", alignItems: "center", gap: 8 },
  logo: { width: 22, height: 22 },
  brandTxt: { color: TEXT, fontSize: 16, fontWeight: "600" },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 10 },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: CARD,
  },
  chipTxt: { color: MUTED, fontSize: 12, fontWeight: "600" },

  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: CARD,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
});
