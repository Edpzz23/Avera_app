// components/ui/themed-text.tsx
import { Colors } from "@/constants/theme";
import { Text, TextProps } from "react-native";

// claves usadas por los diseños
type ColorKey = "text" | "muted" | "stroke" | "purple" | "success" | "danger";

type Props = TextProps & { color?: ColorKey };

const resolveFromColors = (key: ColorKey): string | undefined => {
  const C: any = Colors as any;
  return C?.[key] ?? C?.light?.[key] ?? C?.dark?.[key];
};

const fallback: Record<ColorKey, string> = {
  text: "#EDEDED",
  muted: "rgba(237,237,237,0.6)",
  stroke: "rgba(255,255,255,0.08)",
  purple: "#7C5CFF",
  success: "#7DD957",
  danger: "#FF6B6B",
};

export function ThemedText({ style, color = "text", ...rest }: Props) {
  const resolved = resolveFromColors(color) ?? fallback[color];
  return <Text {...rest} style={[{ color: resolved }, style]} />;
}

export default ThemedText;
