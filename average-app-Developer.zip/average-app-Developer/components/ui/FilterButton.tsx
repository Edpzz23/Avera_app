// components/ui/FilterButton.tsx
import { Colors, radii } from "@/constants/theme";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable, StyleSheet } from "react-native";

export function FilterButton({ onPress }: { onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} style={s.btn} android_ripple={{ color:"#2B2F3A", borderless:true }}>
      <Ionicons name="stats-chart" size={18} color={Colors.fg} />
      {/* alternativas: "stats-chart-outline", "filter", "funnel-outline" */}
    </Pressable>
  );
}

const s = StyleSheet.create({
  btn: {
    width: 40, height: 40, borderRadius: radii.md, borderWidth: 1,
    borderColor: Colors.border, backgroundColor: "#191B23",
    alignItems: "center", justifyContent: "center"
  },
});
