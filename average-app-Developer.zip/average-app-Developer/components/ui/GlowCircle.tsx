import { Colors } from "@/constants/theme";
import { usePulse } from "@/hooks/usePulse";
import { memo } from "react";
import { Animated, Pressable, ViewStyle } from "react-native";

type Props = { size?: number; active?: boolean; onPress?: () => void; style?: ViewStyle };
function GlowCircleCmp({ size = 210, active = false, onPress, style }: Props) {
  const { scale, glow } = usePulse(active);
  return (
    <Animated.View style={[{
      width: size, height: size, borderRadius: size/2,
      backgroundColor: Colors.purpleDark, alignItems:"center", justifyContent:"center"
    }, { transform: [{ scale }] }, style]}>
      <Animated.View style={{
        position:"absolute", width: size+58, height: size+58, borderRadius:(size+58)/2,
        backgroundColor: Colors.purple, opacity: glow
      }}/>
      <Pressable style={{ width:"100%", height:"100%", borderRadius:999 }} onPress={onPress}/>
    </Animated.View>
  );
}
export const GlowCircle = memo(GlowCircleCmp);
