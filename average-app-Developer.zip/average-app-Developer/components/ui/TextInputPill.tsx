import { Colors, radii } from "@/constants/theme";
import Ionicons from "@expo/vector-icons/Ionicons";
import { forwardRef } from "react";
import { StyleSheet, TextInput, TextInputProps, View } from "react-native";

type Props = TextInputProps & { leftIcon?: keyof typeof Ionicons.glyphMap };
export const TextInputPill = forwardRef<TextInput, Props>(({ leftIcon="create-outline", style, ...p }, ref) => (
  <View style={s.wrap}>
    <Ionicons name={leftIcon} size={16} color={Colors.muted} style={s.icon}/>
    <TextInput ref={ref} {...p} style={[s.input, style]} placeholderTextColor={Colors.muted}/>
  </View>
));
const s = StyleSheet.create({
  wrap:{ flex:1, borderWidth:1, borderColor:Colors.border, borderRadius:radii.lg, backgroundColor:"#191B23" },
  icon:{ position:"absolute", left:12, top:12 },
  input:{ minHeight:40, color:Colors.fg, paddingLeft:32, paddingRight:12, paddingVertical:10 },
});
