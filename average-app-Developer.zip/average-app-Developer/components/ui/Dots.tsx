import React from "react";
import { View } from "react-native";

export function Dots({ active = 1, total = 3 }: { active?: number; total?: number }) {
  return (
    <View style={{ flexDirection: "row", gap: 8, marginTop: 12, marginBottom: 12 }}>
      {Array.from({ length: total }).map((_, i) => {
        const on = i + 1 === active;
        return (
          <View
            key={i}
            style={{
              width: on ? 22 : 6,
              height: 6,
              borderRadius: 3,
              backgroundColor: on ? "#C7FF46" : "#2B2F3A",
            }}
          />
        );
      })}
    </View>
  );
}
