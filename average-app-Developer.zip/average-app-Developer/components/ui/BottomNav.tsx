// components/ui/BottomNav.tsx
import Ionicons from "@expo/vector-icons/Ionicons";
import { router, type Href } from "expo-router";
import { Pressable, StyleSheet, View } from "react-native";

const BG = "#0D0E13";
const LIME = "#C7FF46";
const ICON = "#B8BECD";

// Home ahora es "index"
type TabKey = "index" | "transactions" | "profile";

export function BottomNav({ active }: { active: TabKey }) {
  const go = (k: TabKey) => {
    const path = k === "index" ? "/(tabs)" : `/(tabs)/${k}`;
    router.replace(path as Href);
  };

  const Btn = ({ k, icon }: { k: TabKey; icon: keyof typeof Ionicons.glyphMap }) => {
    const isActive = active === k;
    return (
      <Pressable
        onPress={() => go(k)}
        style={[styles.item, isActive && styles.itemActive]}
        android_ripple={{ color: "#2B2F3A", borderless: true }}
      >
        <Ionicons name={icon} size={20} color={isActive ? BG : ICON} />
      </Pressable>
    );
  };

  return (
    <View style={styles.wrap}>
      <Btn k="index" icon="home" />
      <Btn k="transactions" icon="swap-horizontal" />
      <Btn k="profile" icon="person" />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: "absolute",
    bottom: 18,
    alignSelf: "center",
    flexDirection: "row",
    gap: 10,
    padding: 6,
    borderRadius: 999,
    backgroundColor: "rgba(24,26,34,0.9)",
    borderWidth: 1,
    borderColor: "#2B2F3A",
  },
  item: { width: 44, height: 44, borderRadius: 999, alignItems: "center", justifyContent: "center" },
  itemActive: { backgroundColor: LIME },
});
