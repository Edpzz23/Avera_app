import React from "react";
import { Pressable, StyleSheet, Text, ViewStyle } from "react-native";

type Props = {
  label: string;
  onPress?: () => void;
  accessibilityLabel?: string;
  style?: ViewStyle;
};

export function GhostButton({ label, onPress, accessibilityLabel, style }: Props) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || label}
      onPress={onPress}
      style={[styles.btn, style]}
    >
      <Text style={styles.text}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    paddingVertical: 16,
    paddingHorizontal: 28,
    borderRadius: 999,
    borderWidth: 1.2,
    borderColor: "#2B2F3A",
    alignItems: "center",
    justifyContent: "center",
    minWidth: 120,
  },
  text: { color: "white", fontWeight: "700", letterSpacing: 0.3 },
});
