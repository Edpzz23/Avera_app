export const NAV_SPACE = 120; // mismo en Home / Transactions / Profile
export const H_PADDING = 16;
