// components/filters/TimePeriodChip.tsx
import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable, StyleSheet, Text } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Props = {
  label: string;
  onPress: () => void;
  compact?: boolean; // ← nueva prop opcional
};

export default function TimePeriodChip({ label, onPress, compact }: Props) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        s.wrap,
        compact && s.wrapCompact,   // ← aplica variante compacta
        pressed && s.pressed,
      ]}
    >
      <Text style={[s.txt, compact && s.txtCompact]}>{label}</Text>
      <Ionicons name="chevron-down" size={14} color={MUTED} />
    </Pressable>
  );
}

const s = StyleSheet.create({
  wrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: CARD,
  },
  wrapCompact: {
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  txt: { color: TEXT, fontSize: 12, fontWeight: "600" },
  txtCompact: { fontSize: 11 },
  pressed: { opacity: 0.8 },
});
