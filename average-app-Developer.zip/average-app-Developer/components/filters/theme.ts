// components/filters/theme.ts
export const BG     = "#0D0E13";
export const CARD   = "#14151b";
export const STROKE = "#2B2F3A";
export const TEXT   = "#E7EAF3";
export const MUTED  = "#9AA2B1";
export const LIME   = "#C7FF46";
export const PURPLE = "#7C5CFF";
    