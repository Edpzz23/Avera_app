import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Props = { title: string; placeholder?: string; onBack?: () => void };

export default function FiltersHeader({ title, placeholder = "Search", onBack }: Props) {
  return (
    <LinearGradient
      colors={["#14151b", "#0F1016"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={s.wrap}
    >
      <View style={s.top}>
        <Pressable onPress={onBack} style={s.iconBtn}>
          <Ionicons name="chevron-back" size={18} color={TEXT} />
        </Pressable>
        <Text style={s.title}>{title}</Text>
        <View style={{ width: 28 }} />
      </View>

      <View style={s.search}>
        <Ionicons name="search" size={16} color={MUTED} />
        <TextInput
          placeholder={placeholder}
          placeholderTextColor={MUTED}
          style={s.input}
        />
      </View>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  wrap: {
    paddingTop: 8,
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomLeftRadius: 18,
    borderBottomRightRadius: 18,
  },
  top: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  iconBtn: {
    width: 28, height: 28, alignItems: "center", justifyContent: "center",
    borderRadius: 999, backgroundColor: "#161821", borderWidth: 1, borderColor: STROKE,
  },
  title: { color: TEXT, fontSize: 16, fontWeight: "800" },
  search: {
    flexDirection: "row", alignItems: "center", gap: 8,
    backgroundColor: CARD, borderWidth: 1, borderColor: STROKE, borderRadius: 12,
    paddingHorizontal: 12, height: 40,
  },
  input: { color: TEXT, fontSize: 13, flex: 1 },
});
