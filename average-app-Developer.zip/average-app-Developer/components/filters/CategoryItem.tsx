import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { PURPLE, STROKE, TEXT } from "./theme";

type Props = { label: string; selected: boolean; onPress: () => void };

export default function CategoryItem({ label, selected, onPress }: Props) {
  return (
    <Pressable onPress={onPress} style={[s.row, selected && s.rowActive]}>
      <Text style={s.label}>{label}</Text>
      <View style={[s.circle, selected && s.circleActive]}>
        {selected ? <Ionicons name="checkmark" size={12} color="#0D0E13" /> : null}
      </View>
    </Pressable>
  );
}

const s = StyleSheet.create({
  row: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingVertical: 12, paddingHorizontal: 12, borderRadius: 12,
    borderWidth: 1, borderColor: STROKE, backgroundColor: "#10131A", marginBottom: 10,
  },
  rowActive: { borderColor: "#4F39A8" },
  label: { color: TEXT, fontSize: 13, fontWeight: "700" },
  circle: {
    width: 22, height: 22, borderRadius: 999, borderWidth: 2, borderColor: STROKE,
    alignItems: "center", justifyContent: "center",
  },
  circleActive: { backgroundColor: PURPLE, borderColor: PURPLE },
});
