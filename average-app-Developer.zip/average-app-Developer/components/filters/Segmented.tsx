import { Pressable, StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Props = {
  options: Array<"All" | "Expenses" | "Income">;
  value: "All" | "Expenses" | "Income";
  onChange: (v: Props["value"]) => void;
};

export default function Segmented({ options, value, onChange }: Props) {
  return (
    <View style={s.wrap}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <Pressable key={opt} onPress={() => onChange(opt)} style={[s.btn, active && s.active]}>
            <Text style={[s.txt, active && s.txtActive]}>{opt}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function TimePeriodChip({ label, onPress, compact }: { label: string; onPress?: () => void; compact?: boolean }) {
  return (
    <Pressable onPress={onPress} style={[s.timeChip, compact && { paddingVertical: 6, paddingHorizontal: 10, height: undefined }]}>
      <Text style={s.timeTxt}>{label}</Text>
    </Pressable>
  );
}

const s = StyleSheet.create({
  wrap: {
    flexDirection: "row", backgroundColor: CARD, borderWidth: 1, borderColor: STROKE,
    borderRadius: 12, overflow: "hidden",
  },
  btn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 10 },
  txt: { color: MUTED, fontSize: 12, fontWeight: "700" },
  active: { backgroundColor: "#2A215B" },
  txtActive: { color: TEXT },
  timeChip: {
    height: 36, paddingHorizontal: 12, borderRadius: 999,
    borderWidth: 1, borderColor: STROKE, backgroundColor: CARD,
    alignSelf: "flex-start", alignItems: "center", justifyContent: "center",
  },
  timeTxt: { color: MUTED, fontSize: 12, fontWeight: "700" },
});
