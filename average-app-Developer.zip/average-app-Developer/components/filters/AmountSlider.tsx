import { useRef, useState } from "react";
import { LayoutChangeEvent, PanResponder, StyleSheet, Text, View } from "react-native";
import { MUTED, PURPLE, STROKE, TEXT } from "./theme";

type Props = {
  min: number;
  max: number;
  absoluteMin: number;
  absoluteMax: number;
  onChange: (min: number, max: number) => void;
};

export default function AmountSlider({ min, max, absoluteMin, absoluteMax, onChange }: Props) {
  const [w, setW] = useState(1);
  const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

  const xFromVal = (val: number) => ((val - absoluteMin) / (absoluteMax - absoluteMin)) * w;
  const valFromX = (x: number) => Math.round(absoluteMin + (x / w) * (absoluteMax - absoluteMin));

  const [lx, setLx] = useState(() => xFromVal(min));
  const [rx, setRx] = useState(() => xFromVal(max));

  const leftPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (_e, g) => setLx((prev) => clamp(prev + g.dx, 0, rx - 8)),
      onPanResponderRelease: () => onChange(valFromX(lx), valFromX(rx)),
    })
  ).current;

  const rightPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (_e, g) => setRx((prev) => clamp(prev + g.dx, lx + 8, w)),
      onPanResponderRelease: () => onChange(valFromX(lx), valFromX(rx)),
    })
  ).current;

  const onLayout = (e: LayoutChangeEvent) => setW(e.nativeEvent.layout.width);

  const leftPct = (lx / w) * 100;
  const rightPct = (rx / w) * 100;

  return (
    <View>
      <Text style={s.title}>Amount</Text>

      <View style={s.track} onLayout={onLayout}>
        <View style={[s.fill, { left: `${leftPct}%`, width: `${rightPct - leftPct}%` }]} />
        <View style={[s.thumb, { left: Math.max(0, lx - 8) }]} {...leftPan.panHandlers} />
        <View style={[s.thumb, { left: Math.max(0, rx - 8) }]} {...rightPan.panHandlers} />
      </View>

      <View style={s.labels}>
        <Text style={s.small}>${absoluteMin}</Text>
        <Text style={s.current}>${min} — ${max}</Text>
        <Text style={s.small}>${absoluteMax}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  title: { color: TEXT, fontSize: 14, fontWeight: "800", marginBottom: 8 },
  track: {
    height: 26, justifyContent: "center",
    borderRadius: 999, backgroundColor: "rgba(255,255,255,0.06)",
    borderColor: STROKE, borderWidth: 1, paddingHorizontal: 8,
  },
  fill: { position: "absolute", height: 4, backgroundColor: PURPLE, borderRadius: 999 },
  thumb: {
    position: "absolute", width: 16, height: 16, borderRadius: 999,
    backgroundColor: PURPLE, borderWidth: 2, borderColor: "#5e47df",
  },
  labels: {
    marginTop: 8, flexDirection: "row", alignItems: "center", justifyContent: "space-between",
  },
  small: { color: MUTED, fontSize: 11 },
  current: { color: TEXT, fontSize: 12, fontWeight: "700" },
});
