import React from "react";
import { Animated, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

type Props = {
  value: string[];
  options: string[];
  onToggle: (label: string) => void;
};

export default function SmartChips({ value, options, onToggle }: Props) {
  return (
    <View style={s.card}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {options.map((label) => {
          const active = value.includes(label);
          return (
            <Chip key={label} active={active} label={label} onPress={() => onToggle(label)} />
          );
        })}
      </ScrollView>
    </View>
  );
}

function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  const scale = React.useRef(new Animated.Value(1)).current;
  const pressIn = () => Animated.spring(scale, { toValue: 0.97, useNativeDriver: true }).start();
  const pressOut = () => Animated.spring(scale, { toValue: 1, useNativeDriver: true }).start();

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPressIn={pressIn}
        onPressOut={pressOut}
        onPress={onPress}
        style={[
          s.chip,
          active && { backgroundColor: "#2A215B", borderColor: "#4F39A8" },
        ]}
      >
        <Text style={[s.chipTxt, active && { color: TEXT }]}>{label}</Text>
      </Pressable>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  card: {
    backgroundColor: CARD,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: STROKE,
    padding: 12,
    marginBottom: 14,
  },
  chip: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999,
    borderWidth: 1, borderColor: STROKE, backgroundColor: CARD,
  },
  chipTxt: { color: MUTED, fontSize: 12, fontWeight: "700" },
});

