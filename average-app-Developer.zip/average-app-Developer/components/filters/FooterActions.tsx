import { Pressable, StyleSheet, Text, View } from "react-native";
import { LIME, MUTED, STROKE } from "./theme";

type Props = { onClear: () => void; onApply: () => void };

export default function FooterActions({ onClear, onApply }: Props) {
  return (
    <View style={s.wrap}>
      <Pressable style={s.clear} onPress={onClear}>
        <Text style={s.clearTxt}>CLEAR ALL</Text>
      </Pressable>
      <Pressable style={s.apply} onPress={onApply}>
        <Text style={s.applyTxt}>APPLY</Text>
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: {
    position: "absolute", left: 0, right: 0, bottom: 0,
    paddingHorizontal: 16, paddingBottom: 18, paddingTop: 12,
    backgroundColor: "rgba(13,14,19,0.85)",
  },
  clear: {
    flex: 1, height: 44, borderRadius: 999, borderWidth: 1, borderColor: STROKE,
    alignItems: "center", justifyContent: "center", backgroundColor: "#10131A",
  },
  clearTxt: { color: MUTED, fontWeight: "800", letterSpacing: 0.3, fontSize: 12 },
  apply: {
    flex: 1, height: 44, borderRadius: 999, backgroundColor: LIME,
    alignItems: "center", justifyContent: "center", marginTop: 10,
  },
  applyTxt: { color: "#0D0E13", fontWeight: "900", letterSpacing: 0.3, fontSize: 12 },
});
