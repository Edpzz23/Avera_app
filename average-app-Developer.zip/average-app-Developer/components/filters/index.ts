// components/filters/index.ts

export { default as AmountSlider } from "./AmountSlider";
export { default as CategoryItem } from "./CategoryItem";
export { default as FooterActions } from "./FooterActions";
export { default as FiltersHeader } from "./Header";
export { default as Segmented } from "./Segmented";
export { default as SmartChips } from "./SmartChips";
export { default as TimePeriodChip } from "./TimePeriodChip"; // ← OJO: ./ (misma carpeta)

