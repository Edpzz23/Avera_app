import Ionicons from "@expo/vector-icons/Ionicons";
import { StyleSheet, Text, View } from "react-native";
import { MUTED, PURPLE } from "./theme";

type Props = {
  text: string;
  bottom: number; // offset para ponerlo arriba del nav
};

export default function StreakBadge({ text, bottom }: Props) {
  return (
    <View pointerEvents="none" style={[s.wrap, { bottom }]}>
      <View style={s.badge}>
        <Ionicons name="lock-closed-outline" size={14} color={PURPLE} />
        <Text style={s.txt}>{text}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { position: "absolute", left: 0, right: 0, alignItems: "center" },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  txt: { color: MUTED, fontSize: 11, fontWeight: "800" },
});
