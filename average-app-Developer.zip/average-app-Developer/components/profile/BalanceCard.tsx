import Ionicons from "@expo/vector-icons/Ionicons";
import { StyleSheet, Text, View } from "react-native";
import { CARD, LIME, MUTED, PURPLE, STROKE, TEXT } from "./theme";

type Props = {
  total: number;
  income: number;
  expenses: number;
};

const money = (n: number) => {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);
  return `${sign}$${abs.toLocaleString("en-US")}`;
};

export default function BalanceCard({ total, income, expenses }: Props) {
  return (
    <View style={s.card}>
      <View style={s.top}>
        <Ionicons name="wallet-outline" size={18} color={PURPLE} />
        <Text style={s.total}>~{money(total)}</Text>
      </View>

      <Text style={s.label}>Balance</Text>

      <View style={s.row}>
        <View style={s.mini}>
          <View style={s.miniTop}>
            <Ionicons name="leaf-outline" size={14} color={LIME} />
            <Text style={s.miniValue}>{money(income)}</Text>
          </View>
          <Text style={s.miniLabel}>Income</Text>
        </View>

        <View style={s.mini}>
          <View style={s.miniTop}>
            <Ionicons name="cash-outline" size={14} color={TEXT} />
            <Text style={s.miniValue}>{money(expenses)}</Text>
          </View>
          <Text style={s.miniLabel}>Expenses</Text>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  card: {
    backgroundColor: CARD,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    padding: 14,
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 10 },
  },
  top: { flexDirection: "row", alignItems: "center", gap: 8, justifyContent: "center" },
  total: { color: TEXT, fontSize: 22, fontWeight: "900" },
  label: { color: MUTED, fontSize: 12, fontWeight: "700", textAlign: "center", marginTop: 2 },

  row: { flexDirection: "row", gap: 12, marginTop: 12 },
  mini: {
    flex: 1,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
    alignItems: "center",
  },
  miniTop: { flexDirection: "row", alignItems: "center", gap: 6 },
  miniValue: { color: TEXT, fontSize: 14, fontWeight: "900" },
  miniLabel: { color: MUTED, fontSize: 11, marginTop: 6, fontWeight: "700" },
});
