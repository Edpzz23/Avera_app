import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { CARD, MUTED, STROKE, TEXT } from "./theme";

export type SettingItem = {
  label: string;
  icon?: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
};

type Props = {
  title: string;
  items: SettingItem[];
};

export default function SettingsList({ title, items }: Props) {
  return (
    <>
      <Text style={s.sectionTitle}>{title}</Text>

      <View style={s.card}>
        {items.map((it) => (
          <Pressable
            key={it.label}
            onPress={it.onPress}
            style={({ pressed }) => [s.row, pressed && { transform: [{ scale: 0.985 }], opacity: 0.9 }]}
          >
            <View style={s.left}>
              {!!it.icon && <Ionicons name={it.icon} size={18} color={MUTED} />}
              <Text style={s.text}>{it.label}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={MUTED} />
          </Pressable>
        ))}
      </View>
    </>
  );
}

const s = StyleSheet.create({
  sectionTitle: {
    color: TEXT,
    fontSize: 13,
    fontWeight: "900",
    marginTop: 18,
    marginBottom: 10,
  },
  card: {
    backgroundColor: CARD,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    overflow: "hidden",
  },
  row: {
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#1E2230",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: { flexDirection: "row", alignItems: "center", gap: 10 },
  text: { color: TEXT, fontSize: 12, fontWeight: "800" },
});
