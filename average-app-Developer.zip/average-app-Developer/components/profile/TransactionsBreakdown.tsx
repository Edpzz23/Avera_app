import { StyleSheet, Text, View } from "react-native";
import { CARD, LIME, MUTED, PURPLE, STROKE, TEXT } from "./theme";

type Category = { label: string; amount: number; dotColor: string };

type Props = {
  title: string;
  categories: Category[];
  showTotal?: boolean;
};

export default function TransactionsBreakdown({ title, categories, showTotal = true }: Props) {
  const total = Math.max(1, categories.reduce((a, c) => a + c.amount, 0));

  const a = categories[0]?.amount ?? 0;
  const b = categories[1]?.amount ?? 0;

  const pa = a / Math.max(1, a + b);
  const pb = b / Math.max(1, a + b);

  return (
    <>
      <Text style={s.sectionTitle}>{title}</Text>

      <View style={s.card}>
        {categories.map((c) => (
          <View key={c.label} style={s.row}>
            <View style={s.left}>
              <View style={[s.dot, { backgroundColor: c.dotColor }]} />
              <Text style={s.label}>{c.label}</Text>
            </View>
            <Text style={s.amount}>${c.amount.toLocaleString("en-US")}</Text>
          </View>
        ))}

        <View style={s.track}>
          <View style={[s.segA, { flex: pa || 0 }]} />
          <View style={[s.segB, { flex: pb || 0 }]} />
        </View>

        {showTotal && (
          <Text style={s.totalHint}>Total: ${total.toLocaleString("en-US")}</Text>
        )}
      </View>
    </>
  );
}

const s = StyleSheet.create({
  sectionTitle: {
    color: TEXT,
    fontSize: 13,
    fontWeight: "900",
    marginTop: 16,
    marginBottom: 10,
  },
  card: {
    backgroundColor: CARD,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    padding: 14,
  },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  left: { flexDirection: "row", alignItems: "center", gap: 10 },
  dot: { width: 8, height: 8, borderRadius: 999 },
  label: { color: MUTED, fontSize: 12, fontWeight: "700" },
  amount: { color: TEXT, fontSize: 12, fontWeight: "900" },

  track: {
    height: 12,
    borderRadius: 999,
    overflow: "hidden",
    flexDirection: "row",
    backgroundColor: "#1D2029",
    borderWidth: 1,
    borderColor: STROKE,
    marginTop: 6,
  },
  segA: { backgroundColor: PURPLE },
  segB: { backgroundColor: LIME },

  totalHint: { color: MUTED, fontSize: 10, marginTop: 8, fontWeight: "700" },
});
