import Ionicons from "@expo/vector-icons/Ionicons";
import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { BG, TEXT } from "@/components/profile/theme";

type Props = {
  title: string;
  /** Si no lo mandas, por defecto regresa a Profile */
  backTo?: `/${string}`;
};

export default function ScreenHeader({ title, backTo = "/(tabs)/profile" }: Props) {
  const router = useRouter();

  const goBack = () => {
    // Siempre regresar a Profile (evita irse a Home por historial)
    router.replace(backTo as any);
  };

  return (
    <View style={s.wrap}>
      <Pressable onPress={goBack} style={({ pressed }) => [s.back, pressed && s.pressed]}>
        <Ionicons name="chevron-back" size={20} color={TEXT} />
      </Pressable>

      <Text style={s.title} numberOfLines={1}>
        {title}
      </Text>

      <View style={s.rightSpace} />
    </View>
  );
}

const s = StyleSheet.create({
  wrap: {
    height: 52,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: BG,
  },
  back: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },
  pressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  title: {
    flex: 1,
    color: TEXT,
    fontWeight: "900",
    fontSize: 16,
    textAlign: "left",
    paddingLeft: 8,
  },
  rightSpace: { width: 34 },
});
