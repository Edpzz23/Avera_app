import { Image, StyleSheet, Text, View } from "react-native";
import { MUTED, TEXT } from "./theme";

type Props = {
  name: string;
  email: string;
  avatarUrl: string;
};

export default function ProfileHeader({ name, email, avatarUrl }: Props) {
  return (
    <View style={s.wrap}>
      <View style={s.brandRow}>
        <Image
          source={require("@/assets/images/LogoAverage.png")}
          style={s.brandLogo}
          resizeMode="contain"
        />
        <Text style={s.brandText}>Average</Text>
      </View>

      <View style={s.profileBox}>
        <Image source={{ uri: avatarUrl }} style={s.avatar} />
        <Text style={s.name}>{name}</Text>
        <Text style={s.email}>{email}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { marginBottom: 10 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 14 },
  brandLogo: { width: 18, height: 18 },
  brandText: { color: TEXT, fontSize: 14, fontWeight: "700" },

  profileBox: { alignItems: "center" },
  avatar: {
    width: 76,
    height: 76,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.10)",
    marginBottom: 10,
  },
  name: { color: TEXT, fontSize: 16, fontWeight: "800" },
  email: { color: MUTED, fontSize: 12, marginTop: 2 },
});
