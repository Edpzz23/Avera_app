// lib/storage.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
const KEY = 'average:onboardingSeen';

export async function setOnboardingSeen() {
  try { await AsyncStorage.setItem(KEY, '1'); } catch {}
}
export async function getOnboardingSeen(): Promise<boolean> {
  try {
    const v = await AsyncStorage.getItem(KEY);
    return v === '1';
  } catch { return false; }
}
export async function clearOnboardingSeen() {
  try { await AsyncStorage.removeItem(KEY); } catch {}
}
