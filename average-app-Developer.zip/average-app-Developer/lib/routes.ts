// lib/routes.ts
import type { Href } from "expo-router";

export const ROUTES = {
  home: "/home",
  onboarding: {
    step1: "/(onboarding)/step1",
    step2: "/(onboarding)/step2",
    step3: "/(onboarding)/step3",
  },
  auth: {
    registerEmail: "/(auth)/register-email",
  },
  // cuando agregues dashboard/tabs:
  // app: { tabs: "/(tabs)" }
} as const;

export type RouteValue = (typeof ROUTES)[keyof typeof ROUTES] | string;
export const asHref = (r: RouteValue) => r as Href;
