// app/(auth)/register-email.tsx
import { GhostButton } from "@/components/ui/GhostButton";

import { PrimaryButton } from "@/components/ui/PrimaryButton";
import * as ImagePicker from "expo-image-picker";
import { router, type Href } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const BG = "#0D0E13";
const FG = "#FFFFFF";
const MUTED = "#B8BECD";
const BORDER = "#2B2F3A";
const ERROR = "#E5484D";

// Email estándar
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

// Nombre/Apellido:
// Letras (incluye acentos/ñ), un solo espacio interno, guion o apóstrofo.
// 2–40 chars, sin dobles espacios, ni espacios al inicio/fin, sin números.
const nameRegex =
  /^(?=.{2,40}$)(?!.*\s{2})(?!\s)(?!.*\s$)[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+(?:[ '-][A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*$/;

export default function RegisterEmail() {
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [email, setEmail] = useState("");

  const [touched, setTouched] = useState<{ first?: boolean; last?: boolean; email?: boolean }>(
    {}
  );
  const [avatarUri, setAvatarUri] = useState<string | null>(null);

  const firstValid = useMemo(() => nameRegex.test(first.trim()), [first]);
  const lastValid = useMemo(() => nameRegex.test(last.trim()), [last]);
  const emailValid = useMemo(() => emailRegex.test(email.trim()), [email]);

  const formValid = firstValid && lastValid && emailValid;

  useEffect(() => {
    (async () => {
      await ImagePicker.requestMediaLibraryPermissionsAsync();
      await ImagePicker.requestCameraPermissionsAsync();
    })();
  }, []);

  const normalize = (s: string) => s.replace(/\s+/g, " ").trimStart();

  const pickFromLibrary = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });
    if (!res.canceled) setAvatarUri(res.assets[0].uri);
  };

  const takePhoto = async () => {
    const res = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });
    if (!res.canceled) setAvatarUri(res.assets[0].uri);
  };

  const onAvatarPress = () => {
    if (!avatarUri) {
      Alert.alert("Foto de perfil", "¿De dónde tomamos tu foto?", [
        { text: "Cámara", onPress: takePhoto },
        { text: "Galería", onPress: pickFromLibrary },
        { text: "Cancelar", style: "cancel" },
      ]);
    } else {
      Alert.alert("Foto de perfil", "¿Quieres cambiar tu foto?", [
        { text: "Cambiar (Galería)", onPress: pickFromLibrary },
        { text: "Tomar foto", onPress: takePhoto },
        { text: "Quitar", style: "destructive", onPress: () => setAvatarUri(null) },
        { text: "Cancelar", style: "cancel" },
      ]);
    }
  };

const onNext = () => {
  if (!formValid) return;
  router.push("/(onboarding)/select-categories" as Href);
};

const goPrev = () => {
    router.replace("/(onboarding)/step3" as Href);
  };


  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BG }} edges={["top", "bottom"]}>
      <StatusBar style="light" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.select({ ios: "padding", android: undefined })}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            {/* Logo (ajusta la ruta si tu asset es distinto) */}
            <Image
              source={require("@/assets/images/LogoAverage.png")}
              style={{ width: 150, height: 36, marginTop: 6,marginBottom: 18, alignSelf: "center" }}
              resizeMode="contain"
            />

            {/* Avatar */}
            <Pressable onPress={onAvatarPress} style={styles.avatarWrap} accessibilityRole="button">
              {avatarUri ? (
                <Image source={{ uri: avatarUri }} style={styles.avatarImg} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Text style={{ color: MUTED, fontWeight: "700" }}>👤</Text>
                </View>
              )}
            </Pressable>

            {/* First name */}
            <TextInput
              value={first}
              onChangeText={(t) => setFirst(normalize(t))}
              onBlur={() => setTouched((t) => ({ ...t, first: true }))}
              placeholder="Enter first name"
              placeholderTextColor={MUTED}
              autoCapitalize="words"
              returnKeyType="next"
              style={[styles.input, touched.first && !firstValid && styles.inputError]}
            />
            {touched.first && !firstValid && (
              <Text style={styles.errorText}>Solo letras (2–40). Sin números ni símbolos.</Text>
            )}

            {/* Last name */}
            <TextInput
              value={last}
              onChangeText={(t) => setLast(normalize(t))}
              onBlur={() => setTouched((t) => ({ ...t, last: true }))}
              placeholder="Enter last name"
              placeholderTextColor={MUTED}
              autoCapitalize="words"
              returnKeyType="next"
              style={[styles.input, touched.last && !lastValid && styles.inputError]}
            />
            {touched.last && !lastValid && (
              <Text style={styles.errorText}>Solo letras (2–40). Sin números ni símbolos.</Text>
            )}

            {/* Email */}
            <TextInput
              value={email}
              onChangeText={setEmail}
              onBlur={() => setTouched((t) => ({ ...t, email: true }))}
              placeholder="Enter email ID"
              placeholderTextColor={MUTED}
              autoCapitalize="none"
              keyboardType="email-address"
              style={[styles.input, touched.email && !emailValid && styles.inputError]}
            />
            {touched.email && !emailValid && (
              <Text style={styles.errorText}>Please enter correct email ID</Text>
            )}

            {/* Acciones */}
            <View style={styles.footer}>
              <GhostButton label="PREV" onPress={goPrev} />
              <PrimaryButton label="NEXT" onPress={onNext} disabled={!formValid} />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
    backgroundColor: BG,
    alignItems: "center",
  },
  // Evita que el form “crezca” demasiado en Android y mantiene centro
  card: {
    width: "100%",
    maxWidth: 420,
    alignSelf: "center",
  },
  avatarWrap: {
    width: 92,
    height: 92,
    borderRadius: 999,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
    borderWidth: 1.2,
    borderColor: BORDER,
    backgroundColor: "#0F1118",
    alignSelf: "center",
  },
  avatarImg: { width: 92, height: 92, borderRadius: 999 },
  avatarPlaceholder: {
    width: 76,
    height: 76,
    borderRadius: 999,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#141826",
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    borderColor: BORDER,
    color: FG,
    marginTop: 8,
  },
  inputError: {
    borderColor: ERROR,
  },
  errorText: {
    color: ERROR,
    marginTop: 6,
    marginLeft: 6,
    fontSize: 12,
  },
  footer: {
    marginTop: 20,
    width: "100%",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
});
