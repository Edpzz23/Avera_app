// app/(auth)/_layout.tsx
import { Stack } from "expo-router";

export default function AuthLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animation: "slide_from_right",
      }}
    >
      {/* registra aquí tus screens de auth */}
      <Stack.Screen name="register-email" />
    </Stack>
  );
}
