// app/index.tsx
import { Redirect, type Href } from "expo-router";
import * as React from "react";
import { Animated, Easing, Image, StyleSheet, View } from "react-native";

export default function Index() {
  const fade = React.useRef(new Animated.Value(1)).current;
  const [done, setDone] = React.useState(false);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      await new Promise(r => setTimeout(r, 3000)); // 5 s
      Animated.timing(fade, {
        toValue: 0, duration: 300, easing: Easing.out(Easing.quad), useNativeDriver: true
      }).start(() => { if (mounted) setDone(true); });
    })();
    return () => { mounted = false; };
  }, []);

  if (done) return <Redirect href={"/(onboarding)/step1" as Href} />;

  return (
    <View style={styles.root}>
      <Animated.View style={{ alignItems: "center", opacity: fade }}>
        <Image
          source={require("@/assets/images/LogoAverage.png")}
          style={{ width: 160, height: 160 }}
          resizeMode="contain"
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#0D0E13", alignItems: "center", justifyContent: "center" },
  brand: { color: "white", fontSize: 24, fontWeight: "800", marginTop: 4, letterSpacing: 0.3 },
});
