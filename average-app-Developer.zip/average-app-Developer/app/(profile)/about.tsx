import Ionicons from "@expo/vector-icons/Ionicons";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, MUTED, STROKE, TEXT } from "@/components/profile/theme";

function Bullet({ text }: { text: string }) {
  return (
    <View style={s.bulletRow}>
      <Text style={s.bulletDot}>•</Text>
      <Text style={s.p}>{text}</Text>
    </View>
  );
}

export default function AboutScreen() {
  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="About" />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <View style={s.card}>
          <View style={s.brandRow}>
            <Ionicons name="aperture" size={16} color={TEXT} />
            <Text style={s.brand}>Average</Text>
          </View>

          <Text style={s.h}>Our Story</Text>
          <Text style={s.p}>
            Average was created to help people take control of their money without the complexity
            of traditional finance tools. We believe managing expenses should be simple, insightful,
            and stress-free.
          </Text>

          <View style={{ height: 10 }} />

          <Text style={s.h}>Our Mission</Text>
          <Text style={s.p}>
            To empower individuals and families to understand their spending, save more, and achieve
            their financial goals with confidence.
          </Text>

          <View style={{ height: 10 }} />

          <Text style={s.h}>What We Offer</Text>
          <Bullet text="Easy expense & income tracking (manual or voice)." />
          <Bullet text="Smart filters and insights powered by AI." />
          <Bullet text="Beautiful charts to visualize your spending." />
          <Bullet text="Secure cloud backups & restore (planned)." />
          <Bullet text="Customizable budgets and reminders (planned)." />

          <View style={{ height: 10 }} />

          <Text style={s.h}>Our Values</Text>
          <Bullet text="Privacy First — Your data stays yours." />
          <Bullet text="Simplicity — Finance tools should be easy, not overwhelming." />
          <Bullet text="Insightful — Smart tips and patterns that help you spend wisely." />
        </View>

        <View style={{ height: 16 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scroll: { padding: 16, paddingBottom: 24 },

  card: {
    backgroundColor: "rgba(20,21,27,0.55)",
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    padding: 14,
  },

  brandRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
  brand: { color: TEXT, fontWeight: "900", fontSize: 14 },

  h: { color: TEXT, fontWeight: "900", fontSize: 13, marginTop: 6, marginBottom: 6 },
  p: { color: MUTED, fontWeight: "600", fontSize: 12, lineHeight: 18 },

  bulletRow: { flexDirection: "row", gap: 8, marginBottom: 6 },
  bulletDot: { color: MUTED, fontWeight: "900" },
});
