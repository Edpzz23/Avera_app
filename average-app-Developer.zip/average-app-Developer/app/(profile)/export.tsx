import { Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, MUTED, STROKE, TEXT } from "@/components/profile/theme";

export default function ExportScreen() {
  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="Export" />

      <View style={s.body}>
        <Text style={s.label}>Export Data</Text>

        <Pressable style={({ pressed }) => [s.btn, pressed && s.pressed]}>
          <Text style={s.btnText}>Download CSV</Text>
        </Pressable>

        <Text style={s.hint}>
          This is a mock action. Later it will generate a real CSV from your transactions.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  body: { padding: 16, gap: 12 },
  label: { color: MUTED, fontWeight: "800", fontSize: 12 },

  btn: {
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: "rgba(124,92,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  btnText: { color: TEXT, fontWeight: "900" },
  hint: { color: MUTED, fontWeight: "600", fontSize: 12, lineHeight: 18 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.95 },
});
