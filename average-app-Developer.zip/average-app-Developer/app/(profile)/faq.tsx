import Ionicons from "@expo/vector-icons/Ionicons";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, MUTED, STROKE, TEXT } from "@/components/profile/theme";

type FAQItem = {
  q: string;
  a: string;
};

const FAQS: FAQItem[] = [
  {
    q: "How do I add a new expense or income?",
    a: "Tap the green button in the bottom navigation to add an entry. Choose Expense or Income, set category, amount and date, then save.",
  },
  {
    q: "Can I edit or delete a transaction after adding it?",
    a: "Yes. Open the transaction from the Transactions list and use the edit or delete actions. Changes are applied instantly (mock for now).",
  },
  {
    q: "What currencies are supported?",
    a: "You can switch currency in Settings. For now we include USD, MXN and EUR as mock options. More can be added later.",
  },
  {
    q: "How does rounding work?",
    a: "Rounding helps simplify tracking. You can round to the nearest dollar, nearest 5 or nearest 10 (mock). It affects displayed amounts only for now.",
  },
  {
    q: "Will I get reminders to add expenses?",
    a: "Not yet. This UI is ready for reminders, but notifications scheduling is pending backend integration.",
  },
  {
    q: "How do budgets work?",
    a: "Budgets are planned as a future feature. The goal is to set monthly limits by category and track progress automatically.",
  },
  {
    q: "What are smart filters?",
    a: "Smart filters are presets that help you quickly discover patterns like late-night spending or hidden recurring charges. They currently work as UI state only.",
  },
  {
    q: "Can I sync data across devices?",
    a: "Sync is planned. The Restore & Backup screen shows the intended flow (manual backup + restore) but it’s mock for now.",
  },
];

export default function FAQScreen() {
  const [open, setOpen] = React.useState<Record<number, boolean>>({ 0: true });

  const toggle = (idx: number) => {
    setOpen((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="FAQ" />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 12 }}>
          {FAQS.map((item, idx) => {
            const isOpen = !!open[idx];
            return (
              <View key={idx} style={s.card}>
                <Pressable
                  onPress={() => toggle(idx)}
                  style={({ pressed }) => [s.cardHeader, pressed && s.pressed]}
                >
                  <Text style={s.q} numberOfLines={2}>
                    {item.q}
                  </Text>
                  <Ionicons
                    name={isOpen ? "chevron-up" : "chevron-down"}
                    size={18}
                    color={MUTED}
                  />
                </Pressable>

                {isOpen ? (
                  <View style={s.answerWrap}>
                    <Text style={s.a}>{item.a}</Text>
                  </View>
                ) : null}
              </View>
            );
          })}
        </View>

        <View style={{ height: 12 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scroll: { padding: 16, paddingBottom: 24 },

  card: {
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    backgroundColor: "rgba(20,21,27,0.55)",
    overflow: "hidden",
  },

  cardHeader: {
    paddingHorizontal: 14,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },

  q: { flex: 1, color: TEXT, fontWeight: "900", fontSize: 14, lineHeight: 18 },
  answerWrap: { paddingHorizontal: 14, paddingBottom: 14, paddingTop: 2 },
  a: { color: MUTED, fontWeight: "600", lineHeight: 18, fontSize: 12 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.95 },
});
