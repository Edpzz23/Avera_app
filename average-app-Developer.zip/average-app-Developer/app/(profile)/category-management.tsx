import Ionicons from "@expo/vector-icons/Ionicons";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, LIME, MUTED, PURPLE, STROKE, TEXT } from "@/components/profile/theme";

type Category = {
  id: string;
  name: string;
  description: string;
};

const initialSelected: Category[] = [
  {
    id: "essentials",
    name: "The Essentials",
    description: "For the minimalist who wants a simple clean slate.",
  },
  {
    id: "family_home",
    name: "Family & Home",
    description: "For managing household bills, groceries, and family expenses.",
  },
];

const initialAvailable: Category[] = [
  {
    id: "student_life",
    name: "Student Life",
    description: "For tracking campus costs, part-time gigs, and social life.",
  },
  {
    id: "freelancer_pro",
    name: "The Freelancer & Pro",
    description: "For tracking business expenses, client income, and subscriptions.",
  },
];

const ids = (arr: Category[]) => arr.map((x) => x.id).sort().join(",");

function CategoryRow({
  item,
  checked,
  onPress,
}: {
  item: Category;
  checked: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [s.card, pressed && s.pressed, checked && s.cardChecked]}>
      <View style={{ flex: 1 }}>
        <Text style={s.name}>{item.name}</Text>
        <Text style={s.desc}>{item.description}</Text>
      </View>

      <View style={[s.check, checked ? s.checkOn : s.checkOff]}>
        {checked ? <Ionicons name="checkmark" size={16} color={TEXT} /> : null}
      </View>
    </Pressable>
  );
}

export default function CategoryManagementScreen() {
  const insets = useSafeAreaInsets();

  const [selected, setSelected] = React.useState<Category[]>(initialSelected);
  const [available, setAvailable] = React.useState<Category[]>(initialAvailable);

  // base “aplicada”
  const [baseSelected, setBaseSelected] = React.useState<Category[]>(initialSelected);
  const [baseAvailable, setBaseAvailable] = React.useState<Category[]>(initialAvailable);

  const hasChanges =
    ids(selected) !== ids(baseSelected) || ids(available) !== ids(baseAvailable);

  const moveToSelected = (item: Category) => {
    if (selected.some((x) => x.id === item.id)) return;
    setSelected((prev) => [...prev, item]);
    setAvailable((prev) => prev.filter((x) => x.id !== item.id));
  };

  const moveToAvailable = (item: Category) => {
    if (available.some((x) => x.id === item.id)) return;
    setAvailable((prev) => [...prev, item]);
    setSelected((prev) => prev.filter((x) => x.id !== item.id));
  };

  const onCancel = () => {
    setSelected(baseSelected);
    setAvailable(baseAvailable);
  };

  const onApply = () => {
    if (!hasChanges) return;
    setBaseSelected(selected);
    setBaseAvailable(available);
  };

  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="Category Management" />

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 140 }} showsVerticalScrollIndicator={false}>
        <Text style={s.section}>Selected</Text>
        <View style={{ gap: 10, marginBottom: 16 }}>
          {selected.map((c) => (
            <CategoryRow key={c.id} item={c} checked onPress={() => moveToAvailable(c)} />
          ))}
        </View>

        <Text style={s.section}>Available</Text>
        <View style={{ gap: 10 }}>
          {available.map((c) => (
            <CategoryRow key={c.id} item={c} checked={false} onPress={() => moveToSelected(c)} />
          ))}
        </View>
      </ScrollView>

      <View style={[s.footer, { paddingBottom: Math.max(insets.bottom, 12) }]}>
        <Pressable onPress={onCancel} style={({ pressed }) => [s.btn, s.btnGhost, pressed && s.pressed]}>
          <Text style={s.btnGhostText}>CANCEL</Text>
        </Pressable>

        <Pressable
          onPress={onApply}
          disabled={!hasChanges}
          style={({ pressed }) => [
            s.btn,
            hasChanges ? s.btnApply : s.btnApplyDisabled,
            pressed && hasChanges ? s.pressed : null,
          ]}
        >
          <Text style={hasChanges ? s.btnApplyText : s.btnApplyTextDisabled}>APPLY</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },

  section: { color: TEXT, fontWeight: "900", fontSize: 14, marginBottom: 10 },

  card: {
    flexDirection: "row",
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: "rgba(20,21,27,0.55)",
    alignItems: "center",
  },
  cardChecked: { borderColor: "rgba(124,92,255,0.8)", backgroundColor: "rgba(124,92,255,0.10)" },

  name: { color: TEXT, fontWeight: "900" },
  desc: { color: MUTED, fontWeight: "600", fontSize: 12, marginTop: 4, lineHeight: 16 },

  check: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  checkOn: { borderColor: PURPLE, backgroundColor: "rgba(124,92,255,0.9)" },
  checkOff: { borderColor: STROKE, backgroundColor: "transparent" },

  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: "rgba(13,14,19,0.92)",
    borderTopWidth: 1,
    borderTopColor: "rgba(43,47,58,0.8)",
    flexDirection: "row",
    gap: 12,
  },

  btn: {
    flex: 1,
    height: 44,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },

  btnGhost: {
    backgroundColor: "rgba(255,255,255,0.03)",
    borderWidth: 1,
    borderColor: STROKE,
  },
  btnGhostText: { color: MUTED, fontWeight: "900", letterSpacing: 0.5 },

  btnApply: { backgroundColor: LIME },
  btnApplyDisabled: {
    backgroundColor: "rgba(199,255,70,0.18)",
    borderWidth: 1,
    borderColor: "rgba(199,255,70,0.25)",
  },
  btnApplyText: { color: "#0B0C10", fontWeight: "900", letterSpacing: 0.5 },
  btnApplyTextDisabled: { color: "rgba(231,234,243,0.35)", fontWeight: "900" },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.95 },
});
