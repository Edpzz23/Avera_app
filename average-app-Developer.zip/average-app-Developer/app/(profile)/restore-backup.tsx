import Ionicons from "@expo/vector-icons/Ionicons";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, LIME, MUTED, STROKE, TEXT } from "@/components/profile/theme";

type Backup = { id: string; label: string; detail: string };

const BACKUPS: Backup[] = [
  { id: "b1", label: "Aug 28, 2025 — 10:15 AM (iCloud)", detail: "Last Backup Info" },
  { id: "b2", label: "Aug 20, 2025 — 09:40 PM (Local)", detail: "Last Backup Info" },
];

export default function RestoreBackupScreen() {
  const [selected, setSelected] = React.useState<string>(BACKUPS[0]?.id ?? "b1");

  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="Restore & Backup" />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        {/* Backup */}
        <Text style={s.section}>Backup</Text>

        <View style={s.card}>
          <Text style={s.rowLabel}>Manual Backup</Text>

          <Pressable style={({ pressed }) => [s.linkBtn, pressed && s.pressed]}>
            <Text style={s.linkText}>Create Backup Now</Text>
            <Ionicons name="chevron-forward" size={16} color={LIME} />
          </Pressable>
        </View>

        {/* Backups */}
        <View style={{ height: 14 }} />
        <Text style={s.section}>Backups</Text>

        <View style={s.card}>
          <View style={{ gap: 10 }}>
            {BACKUPS.map((b) => {
              const active = b.id === selected;
              return (
                <Pressable
                  key={b.id}
                  onPress={() => setSelected(b.id)}
                  style={({ pressed }) => [
                    s.pickRow,
                    active && s.pickRowActive,
                    pressed && s.pressed,
                  ]}
                >
                  <Text style={s.pickLeft}>Backups</Text>
                  <View style={s.pickRight}>
                    <Text style={s.pickValue} numberOfLines={1}>
                      {b.label}
                    </Text>
                    <Ionicons name="chevron-down" size={16} color={MUTED} />
                  </View>
                </Pressable>
              );
            })}
          </View>

          <View style={s.divider} />

          <View style={s.infoRow}>
            <Text style={s.pickLeft}>Last Backup Info</Text>
            <Text style={s.smallMuted}>Aug 28, 2025 at 10:15 AM</Text>
          </View>
        </View>

        {/* Restore */}
        <View style={{ height: 14 }} />
        <Text style={s.section}>Restore</Text>

        <View style={s.card}>
          <Pressable style={({ pressed }) => [s.pickRow, pressed && s.pressed]}>
            <Text style={s.pickLeft}>Choose Backup</Text>
            <View style={s.pickRight}>
              <Text style={[s.pickValue, { color: LIME }]} numberOfLines={1}>
                {BACKUPS.find((b) => b.id === selected)?.label ?? "Select"}
              </Text>
              <Ionicons name="chevron-down" size={16} color={MUTED} />
            </View>
          </Pressable>

          <Text style={s.note}>
            Restoring will replace your current data. Make sure you've backed up first.
          </Text>
        </View>

        <View style={{ height: 18 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scroll: { padding: 16, paddingBottom: 24 },

  section: { color: TEXT, fontWeight: "900", fontSize: 14, marginBottom: 10 },

  card: {
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    backgroundColor: "rgba(20,21,27,0.55)",
    padding: 14,
    gap: 12,
  },

  rowLabel: { color: MUTED, fontWeight: "800", fontSize: 12 },

  linkBtn: { flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "flex-end" },
  linkText: { color: LIME, fontWeight: "900" },

  pickRow: {
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "rgba(43,47,58,0.8)",
    paddingHorizontal: 12,
    backgroundColor: "rgba(255,255,255,0.02)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },
  pickRowActive: { borderColor: "rgba(199,255,70,0.35)" },
  pickLeft: { color: MUTED, fontWeight: "800" },
  pickRight: { flex: 1, flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 8 },
  pickValue: { color: TEXT, fontWeight: "800", maxWidth: "85%" },

  divider: { height: 1, backgroundColor: "rgba(43,47,58,0.7)", marginVertical: 4 },
  infoRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  smallMuted: { color: MUTED, fontWeight: "700", fontSize: 12 },

  note: { color: MUTED, fontWeight: "600", fontSize: 12, lineHeight: 18 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.95 },
});
