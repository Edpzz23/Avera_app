import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, MUTED, STROKE, TEXT } from "@/components/profile/theme";

export default function PrivacyPolicyScreen() {
  const content = ""; // vacío por ahora

  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="Privacy & Policy" />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <View style={s.card}>
          {content.trim().length === 0 ? (
            <View style={s.empty}>
              <Text style={s.emptyTitle}>No content yet</Text>
              <Text style={s.emptyText}>
                This area is prepared for long text. Add your policy here later.
              </Text>
            </View>
          ) : (
            <Text style={s.text}>{content}</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scroll: { padding: 16, paddingBottom: 24 },
  card: {
    backgroundColor: "rgba(20,21,27,0.55)",
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    padding: 14,
    minHeight: 520,
  },
  text: { color: TEXT, lineHeight: 20, fontWeight: "600" },
  empty: { paddingVertical: 18, gap: 8 },
  emptyTitle: { color: TEXT, fontWeight: "900", fontSize: 16 },
  emptyText: { color: MUTED, fontWeight: "600", lineHeight: 18 },
});
