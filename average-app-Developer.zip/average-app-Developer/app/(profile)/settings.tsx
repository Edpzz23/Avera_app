import Ionicons from "@expo/vector-icons/Ionicons";
import React from "react";
import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import ScreenHeader from "@/components/profile/common/ScreenHeader";
import { BG, CARD, MUTED, PURPLE, STROKE, TEXT } from "@/components/profile/theme";

type Option = { label: string; value: string };

const currencies: Option[] = [
  { label: "US Dollars ($)", value: "US Dollars ($)" },
  { label: "Mexican Peso (MXN)", value: "Mexican Peso (MXN)" },
  { label: "Euro (€)", value: "Euro (€)" },
];

const roundings: Option[] = [
  { label: "Nearest Dollar", value: "Nearest Dollar" },
  { label: "Nearest 5", value: "Nearest 5" },
  { label: "Nearest 10", value: "Nearest 10" },
];

function Row({
  label,
  right,
  onPress,
}: {
  label: string;
  right: React.ReactNode;
  onPress?: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [
        s.row,
        pressed && onPress ? s.pressed : null,
      ]}
    >
      <Text style={s.rowLabel}>{label}</Text>
      <View style={s.rowRight}>{right}</View>
    </Pressable>
  );
}

function InlineSelect({
  open,
  title,
  options,
  value,
  onClose,
  onSelect,
}: {
  open: boolean;
  title: string;
  options: Option[];
  value: string;
  onClose: () => void;
  onSelect: (v: string) => void;
}) {
  if (!open) return null;

  return (
    <View style={s.modalOverlay}>
      <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />

      <View style={s.modalCard}>
        <View style={s.modalHeader}>
          <Text style={s.modalTitle}>{title}</Text>
          <Pressable onPress={onClose} style={({ pressed }) => [s.modalClose, pressed && s.pressed]}>
            <Ionicons name="close" size={18} color={TEXT} />
          </Pressable>
        </View>

        <View style={{ gap: 8 }}>
          {options.map((o) => {
            const active = o.value === value;
            return (
              <Pressable
                key={o.value}
                onPress={() => {
                  onSelect(o.value);
                  onClose();
                }}
                style={({ pressed }) => [
                  s.opt,
                  active && s.optActive,
                  pressed && s.pressed,
                ]}
              >
                <Text style={[s.optText, active && s.optTextActive]}>{o.label}</Text>
                {active ? <Ionicons name="checkmark" size={18} color={PURPLE} /> : null}
              </Pressable>
            );
          })}
        </View>
      </View>
    </View>
  );
}

export default function SettingsScreen() {
  const [notifications, setNotifications] = React.useState(true);
  const [currency, setCurrency] = React.useState(currencies[0].value);
  const [rounding, setRounding] = React.useState(roundings[0].value);

  const [openCurrency, setOpenCurrency] = React.useState(false);
  const [openRounding, setOpenRounding] = React.useState(false);

  return (
    <SafeAreaView style={s.screen}>
      <ScreenHeader title="Settings" />

      <View style={s.content}>
        <Row
          label="Notifications"
          right={
            <View style={s.inlineRight}>
              <Text style={s.value}>{notifications ? "On" : "Off"}</Text>
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ false: "#2B2F3A", true: "rgba(124,92,255,0.45)" }}
                thumbColor={notifications ? PURPLE : "#8A92A3"}
              />
            </View>
          }
        />

        <Row
          label="Currency"
          onPress={() => setOpenCurrency(true)}
          right={
            <View style={s.inlineRight}>
              <Text style={s.value}>{currency}</Text>
              <Ionicons name="chevron-down" size={16} color={MUTED} />
            </View>
          }
        />

        <Row
          label="Rounding"
          onPress={() => setOpenRounding(true)}
          right={
            <View style={s.inlineRight}>
              <Text style={s.value}>{rounding}</Text>
              <Ionicons name="chevron-down" size={16} color={MUTED} />
            </View>
          }
        />
      </View>

      <InlineSelect
        open={openCurrency}
        title="Currency"
        options={currencies}
        value={currency}
        onClose={() => setOpenCurrency(false)}
        onSelect={setCurrency}
      />

      <InlineSelect
        open={openRounding}
        title="Rounding"
        options={roundings}
        value={rounding}
        onClose={() => setOpenRounding(false)}
        onSelect={setRounding}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  content: { padding: 16, gap: 12 },

  row: {
    backgroundColor: "rgba(20,21,27,0.55)",
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 18,
    paddingHorizontal: 14,
    height: 54,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  rowLabel: { color: TEXT, fontWeight: "800" },
  rowRight: { alignItems: "flex-end" },
  inlineRight: { flexDirection: "row", alignItems: "center", gap: 10 },

  value: { color: MUTED, fontWeight: "800" },
  pressed: { transform: [{ scale: 0.99 }], opacity: 0.92 },

  // "modal" inline
  modalOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "flex-end",
    padding: 14,
  },
  modalCard: {
    backgroundColor: CARD,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 20,
    padding: 14,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  modalTitle: { color: TEXT, fontWeight: "900", fontSize: 16 },
  modalClose: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },

  opt: {
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: STROKE,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "rgba(255,255,255,0.02)",
  },
  optActive: {
    borderColor: "rgba(124,92,255,0.8)",
    backgroundColor: "rgba(124,92,255,0.12)",
  },
  optText: { color: TEXT, fontWeight: "700" },
  optTextActive: { color: TEXT },
});
