// app/(tabs)/_layout.tsx
import { Tabs } from "expo-router";

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarStyle: { display: "none" } }}>
      <Tabs.Screen name="index" />        
      <Tabs.Screen name="transactions" />
      <Tabs.Screen name="profile" />
      <Tabs.Screen name="interpret" options={{ href: null }} />
    </Tabs>
  );
}
