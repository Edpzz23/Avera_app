import {
  BalanceCard,
  BG,
  DashboardHeader,
  InsightCard,
  TransactionsList,
  WeeklyChart,
} from "@/components/dashboard";
import { BottomNav } from "@/components/ui/BottomNav";
import { H_PADDING, NAV_SPACE } from "@/components/ui/layout";
import { ScrollView, StyleSheet, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const week = [
  { d: "MO", v: 25 },
  { d: "TU", v: 40 },
  { d: "WE", v: 65 },
  { d: "TH", v: 55 },
  { d: "FR", v: 90 },
  { d: "SA", v: 110 },
  { d: "SU", v: 75 },
];

const txs = [
  { name: "Coffee", when: "Aug 16, 9:15 AM", amt: -4.5 },
  { name: "Bus Ticket", when: "Aug 16, 11:30 AM", amt: -1.2 },
  { name: "Electricity Bill", when: "Aug 15, 7:00 PM", amt: -42.0 },
  { name: "Salary", when: "Aug 15, 10:00 AM", amt: 2800 },
  { name: "Groceries", when: "Aug 14, 6:45 PM", amt: -95.3 },
  { name: "Rent", when: "Aug 13, 9:20 PM", amt: -12.0 },
  { name: "Gas Station", when: "Aug 13, 8:10 AM", amt: -40.0 },
  { name: "Netflix", when: "Aug 12, 10:00 PM", amt: -15.99 },
];

export default function Transactions() {
  return (
    <SafeAreaView style={s.screen}>
      <DashboardHeader />

      <ScrollView
        contentContainerStyle={s.scroll}
        showsVerticalScrollIndicator={false}
      >
        <BalanceCard
          balance="$1,250"
          subtitle="left this month"
          income="$3,500"
          expenses="$2,250"
        />
        <WeeklyChart title="This Week Expenses" data={week} />

        <View style={s.row2}>
          <InsightCard
            title="40%"
            subtitle="You spent 40% more on dining this month than usual."
            icon="pie-chart"
          />
          <InsightCard
            title="$220/mo"
            subtitle="Total Recurring payments this month"
            icon="trending-up"
            progress={0.6}
          />
        </View>

        <TransactionsList title="Transactions" items={txs} />

        {/* espacio consistente para BottomNav */}
        <View style={{ height: NAV_SPACE }} />
      </ScrollView>
      
      <BottomNav active="transactions" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scroll: { padding: H_PADDING, paddingTop: 10 },
  row2: { flexDirection: "row", gap: 12, marginBottom: 14 },
});
