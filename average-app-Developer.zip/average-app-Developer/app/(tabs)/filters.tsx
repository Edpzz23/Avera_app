import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  AmountSlider,
  CategoryItem,
  FiltersHeader,
  FooterActions,
  Segmented,
  SmartChips,
  TimePeriodChip,
} from "@/components/filters";

import { BG, CARD, MUTED, PURPLE, STROKE, TEXT } from "@/components/filters/theme";

type TxType = "All" | "Expenses" | "Income";
type RecType = "All" | "Recurring" | "One-time";

const smartChipsSeed = [
  "Weekend Spending",
  "Late-Night Purchases",
  "Cash Withdrawals",
  "Travel & Commute",
  "Hidden Recurring Charges",
  "Festival Shopping",
];

const categoriesSeed = [
  { key: "food", label: "Food & Dining" },
  { key: "transport", label: "Transportation" },
  { key: "shopping", label: "Shopping" },
  { key: "house", label: "Household" },
  { key: "other", label: "Other" },
];

export default function Filters() {
  const router = useRouter();

  const [chips, setChips] = useState<string[]>(["Late-Night Purchases"]);
  const [type, setType] = useState<TxType>("All");
  const [period, setPeriod] = useState<string>("This Week");

  const [selected, setSelected] = useState<Record<string, boolean>>({
    food: true,
    transport: true,
    shopping: false,
    house: true,
    other: false,
  });

  const [min, setMin] = useState(80);
  const [max, setMax] = useState(600);

  const [recurring, setRecurring] = useState<RecType>("All");

  const selectedCount = useMemo(
    () => Object.values(selected).filter(Boolean).length,
    [selected]
  );

  const allSelected = selectedCount === categoriesSeed.length;

  const toggleChip = (label: string) => {
    setChips((prev) =>
      prev.includes(label) ? prev.filter((x) => x !== label) : [...prev, label]
    );
  };

  const toggleCategory = (key: string) => {
    setSelected((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleAllCategories = () => {
    const next = !allSelected;
    const obj: Record<string, boolean> = {};
    categoriesSeed.forEach((c) => (obj[c.key] = next));
    setSelected(obj);
  };

  const clearAll = () => {
    setChips([]);
    setType("All");
    setPeriod("This Week");
    setRecurring("All");
    setSelected({
      food: false,
      transport: false,
      shopping: false,
      house: false,
      other: false,
    });
    setMin(0);
    setMax(1000);
  };

  return (
    <SafeAreaView style={s.screen}>
      <View style={s.container}>
        <FiltersHeader
          title="Filters"
          placeholder="Search anything"
          onBack={() =>router.replace("/(tabs)/transactions")}
        />

        <ScrollView
          contentContainerStyle={s.scroll}
          showsVerticalScrollIndicator={false}
        >
          <Text style={s.sectionTitle}>Smart Filters (6)</Text>
          <SmartChips value={chips} options={smartChipsSeed} onToggle={toggleChip} />

          <Text style={s.sectionTitle}>Transaction Type</Text>
          <Segmented
            options={["All", "Expenses", "Income"]}
            value={type}
            onChange={setType}
          />

          <View style={s.rowBetween}>
            <Text style={s.sectionTitle}>Time Period</Text>
            <TimePeriodChip label={period} onPress={() => {}} compact />
          </View>

          <View style={s.rowBetween}>
            <Text style={s.sectionTitle}>Categories ({categoriesSeed.length})</Text>
            <Pressable onPress={toggleAllCategories} style={s.selectAll}>
              <Text style={s.selectAllTxt}>{allSelected ? "Unselect All" : "Select All"}</Text>
              <View style={[s.dot, allSelected && { backgroundColor: PURPLE, borderColor: PURPLE }]} />
            </Pressable>
          </View>

          {categoriesSeed.map((c) => (
            <CategoryItem
              key={c.key}
              label={c.label}
              selected={!!selected[c.key]}
              onPress={() => toggleCategory(c.key)}
            />
          ))}

          <AmountSlider
            min={min}
            max={max}
            absoluteMin={0}
            absoluteMax={1000}
            onChange={(mn, mx) => {
              setMin(mn);
              setMax(mx);
            }}
          />

          <Text style={[s.sectionTitle, { marginTop: 16 }]}>Repeating vs. One-off</Text>
          <View style={s.recWrap}>
            {(["All", "Recurring", "One-time"] as RecType[]).map((opt) => {
              const active = recurring === opt;
              return (
                <Pressable
                  key={opt}
                  onPress={() => setRecurring(opt)}
                  style={[s.recBtn, active && s.recActive]}
                >
                  <Text style={[s.recTxt, active && s.recTxtActive]}>{opt}</Text>
                </Pressable>
              );
            })}
          </View>

          {/* espacio para que el footer sticky no tape */}
          <View style={{ height: 120 }} />
        </ScrollView>

        <FooterActions onClear={clearAll} onApply={() => router.replace("/(tabs)/transactions")} />

      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  container: { flex: 1, position: "relative" },
  scroll: { padding: 16, paddingTop: 12 },

  sectionTitle: {
    color: TEXT,
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 10,
  },

  rowBetween: {
    marginTop: 14,
    marginBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  selectAll: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: CARD,
  },
  selectAllTxt: { color: MUTED, fontSize: 11, fontWeight: "800" },
  dot: {
    width: 14,
    height: 14,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: STROKE,
    backgroundColor: "transparent",
  },

  recWrap: {
    flexDirection: "row",
    backgroundColor: CARD,
    borderWidth: 1,
    borderColor: STROKE,
    borderRadius: 12,
    overflow: "hidden",
  },
  recBtn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 10 },
  recTxt: { color: MUTED, fontSize: 12, fontWeight: "700" },
  recActive: { backgroundColor: "#2A215B" },
  recTxtActive: { color: TEXT },
});
