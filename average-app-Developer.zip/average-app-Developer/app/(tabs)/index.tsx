import Ionicons from "@expo/vector-icons/Ionicons";
import { useRouter } from "expo-router";
import React from "react";
import {
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

import { BottomNav } from "../../components/ui/BottomNav";
import { GlowCircle } from "../../components/ui/GlowCircle";
import { H_PADDING, NAV_SPACE } from "../../components/ui/layout";
import { Colors, radii } from "../../constants/theme";

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();

  const [listening, setListening] = React.useState(false);
  const [typed, setTyped] = React.useState("");

  // Orb responsivo (para que NO se vea amontonado)
  const orbSize = Math.min(Math.round(width * 0.72), 320);
  const composerBottom = NAV_SPACE + 12; // siempre arriba del nav

  const goInterpret = (t: string) => {
    router.push({ pathname: "/(tabs)/interpret", params: { t } } as never);
  };

  const toggleListening = () => {
    if (!listening) {
      setListening(true);
      return;
    }
    setListening(false);

    setTimeout(() => {
      const transcript =
        "Today I had coffee for 150, a bus ticket for 50, and paid 2000 for electricity...";
      goInterpret(transcript);
    }, 450);
  };

  const sendTyped = () => {
    const t = typed.trim();
    if (!t) return;
    setTyped("");
    goInterpret(t);
  };

  return (
    <SafeAreaView style={s.screen}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {/* Tap afuera para cerrar teclado */}
        <Pressable style={{ flex: 1 }} onPress={Keyboard.dismiss} accessible={false}>
          {/* HEADER */}
          <View style={[s.header, { paddingTop: 6 }]}>
            <View style={s.brandRow}>
              <Image
                source={require("../../assets/images/LogoAverage.png")}
                style={s.logo}
                resizeMode="contain"
              />
              <View style={s.logoDot} />
              {/* Si no quieres el puntito, bórralo */}
            </View>
          </View>

          {/* BODY: orb centrado usando el espacio disponible */}
          <View style={s.body}>
            <View style={s.centerWrap}>
              <View
                style={[
                  s.orbOuter,
                  {
                    width: orbSize,
                    height: orbSize,
                    borderRadius: orbSize / 2,
                  },
                ]}
              >
                <View
                  style={[
                    s.orbInner,
                    {
                      width: Math.round(orbSize * 0.78),
                      height: Math.round(orbSize * 0.78),
                      borderRadius: Math.round(orbSize * 0.78) / 2,
                    },
                  ]}
                />
              </View>

              {/* GlowCircle encima del orb (si quieres que sea el botón principal) */}
              <View style={s.glowOverlay}>
                <GlowCircle active={listening} onPress={toggleListening} />
              </View>
            </View>
          </View>

          {/* COMPOSER anclado arriba del nav */}
          <View
            style={[
              s.composerWrap,
              {
                bottom: composerBottom + insets.bottom * 0.2,
                left: H_PADDING,
                right: H_PADDING,
              },
            ]}
          >
            <View style={s.composerRow}>
              <Pressable
                onPress={() => {}}
                style={({ pressed }) => [s.iconBtn, pressed && s.press]}
                android_ripple={{ color: "#2B2F3A", borderless: true }}
              >
                <Image
                  source={require("../../assets/images/math.png")}
                  style={s.iconImg}
                  resizeMode="contain"
                />
              </Pressable>

              <View style={s.inputWrap}>
                <Ionicons
                  name="create-outline"
                  size={16}
                  color={Colors.muted}
                  style={s.inputIcon}
                />
                <TextInput
                  value={typed}
                  onChangeText={setTyped}
                  placeholder="What did you spend/earn?"
                  placeholderTextColor={Colors.muted}
                  style={s.input}
                  blurOnSubmit
                  returnKeyType="send"
                  onSubmitEditing={sendTyped}
                />
              </View>

              <Pressable
                onPress={sendTyped}
                style={({ pressed }) => [s.sendBtn, pressed && s.press]}
                android_ripple={{ color: "#2B2F3A" }}
              >
                <Ionicons name="play" size={18} color={Colors.fg} />
              </Pressable>
            </View>
          </View>

          {/* NAV fijo abajo (desde la pantalla) */}
          <View style={[s.navFixed, { paddingBottom: insets.bottom }]}>
            <BottomNav active="index" />
          </View>
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg },

  header: {
    paddingHorizontal: H_PADDING,
  },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  logo: { width: 150, height: 36 },
  logoDot: {
    width: 8,
    height: 8,
    borderRadius: 99,
    backgroundColor: "transparent",
  },

  body: {
    flex: 1,
    paddingHorizontal: H_PADDING,
    paddingTop: 10,
    paddingBottom: NAV_SPACE + 90, // reserva para composer + nav
  },

  centerWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  orbOuter: {
    backgroundColor: "rgba(124,92,255,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  orbInner: {
    backgroundColor: "rgba(124,92,255,0.28)",
  },

  // GlowCircle centrado encima del orb
  glowOverlay: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },

  composerWrap: {
    position: "absolute",
  },
  composerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  iconBtn: {
    width: 44,
    height: 44,
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: "#191B23",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  iconImg: { width: 18, height: 18, tintColor: Colors.fg },

  inputWrap: {
    flex: 1,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 14,
    backgroundColor: "#191B23",
    height: 44,
    justifyContent: "center",
    position: "relative",
  },
  inputIcon: { position: "absolute", left: 12 },
  input: {
    height: 44,
    color: Colors.fg,
    paddingLeft: 34,
    paddingRight: 12,
    fontWeight: "700",
  },

  sendBtn: {
    width: 54,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: "#191B23",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  press: { transform: [{ scale: 0.98 }], opacity: 0.95 },

  // Esto fuerza a que el nav SIEMPRE esté igual abajo
  navFixed: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
  },
});
