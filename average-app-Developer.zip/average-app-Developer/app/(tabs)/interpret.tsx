// app/(tabs)/interpret.tsx
import { Colors, radii } from "@/constants/theme";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function Interpret() {
  const { t } = useLocalSearchParams<{ t?: string }>();
  const [value, setValue] = React.useState((t ?? "").toString());

  const onAnalyze = () => {
    const text = value.trim();
    if (!text) return;
    // TODO: llamar a Gemini y guardar en DB local
    router.replace("/(tabs)");
  };

  return (
    <SafeAreaView style={s.screen}>
      {/* Logo como en Home */}
      <Image
        source={require("../../assets/images/LogoAverage.png")}
        style={s.logo}
        resizeMode="contain"
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.select({ ios: "padding" })}
        keyboardVerticalOffset={12}
      >
        <Pressable style={{ flex: 1 }} onPress={Keyboard.dismiss} accessible={false}>
          {/* Texto EDITABLE sin caja, sin borde, sin fondo */}
          <View style={s.textAreaPad}>
            <TextInput
              value={value}
              onChangeText={setValue}
              placeholder=" "
              style={s.bigEditable}
              placeholderTextColor="transparent"
              multiline
              textAlignVertical="top"
              returnKeyType="done"
              onSubmitEditing={onAnalyze}
              blurOnSubmit={Platform.OS !== "ios"}
            />
          </View>
        </Pressable>

        {/* Botonera inferior */}
        <View style={s.footer}>
          <Pressable onPress={() => router.back()} style={[s.btn, s.btnGhost]}>
            <Text style={s.btnGhostText}>CANCEL</Text>
          </Pressable>

          <Pressable
            onPress={onAnalyze}
            style={[s.btn, s.btnPrimary, !value.trim() && s.btnDisabled]}
            disabled={!value.trim()}
          >
            <Text style={s.btnPrimaryText}>ANALYZE</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg, paddingHorizontal: 16 },
  logo: { width: 150, height: 36, marginTop: 10, alignSelf: "flex-start" },

  // solo dejamos padding lateral/superior para que el texto no choque
  textAreaPad: {
    flex: 1,
    paddingTop: 12,
    paddingHorizontal: 4,
  },

  // idéntico al mock: texto blanco grande, bold, sin caja
  bigEditable: {
    flex: 1,
    color: "#fff",
    fontSize: 18,
    lineHeight: 26,
    fontWeight: "700",
  },

  footer: { flexDirection: "row", gap: 12, paddingVertical: 16 },
  btn: {
    flex: 1,
    height: 48,
    borderRadius: radii.lg,
    alignItems: "center",
    justifyContent: "center",
  },
  btnGhost: { borderWidth: 1, borderColor: Colors.border, backgroundColor: "#191B23" },
  btnGhostText: { color: "#C9D0E1", fontWeight: "700" },
  btnPrimary: { backgroundColor: Colors.lime },
  btnPrimaryText: { color: "#111", fontWeight: "800" },
  btnDisabled: { opacity: 0.5 },
});
