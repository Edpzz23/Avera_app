import { LinearGradient } from "expo-linear-gradient";
import { Href, useRouter } from "expo-router";
import { ScrollView, StyleSheet, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { BottomNav } from "@/components/ui/BottomNav";
import { H_PADDING, NAV_SPACE } from "@/components/ui/layout";

import {
  BG,
  BalanceCard,
  LIME,
  PURPLE,
  ProfileHeader,
  SettingItem,
  SettingsList,
  StreakBadge,
  TransactionsBreakdown,
} from "@/components/profile";

export default function Profile() {
  const router = useRouter();
  const go = (path: string) => router.push(path as Href);

  const user = {
    name: "John Doe",
    email: "johndoe12@gmail.com",
    avatarUrl:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop",
  };

  const balance = { total: -7710, income: 75587, expenses: -67877 };

  const categories = [
    { label: "The Essentials", amount: 47514, dotColor: PURPLE },
    { label: "Family & Home", amount: 20363, dotColor: LIME },
  ];

  const settings: SettingItem[] = [
    { label: "Settings", icon: "settings-outline", onPress: () => go("/(profile)/settings") },
    {
      label: "Privacy & Security",
      icon: "shield-checkmark-outline",
      onPress: () => go("/(profile)/privacy-policy"),
    },
    {
      label: "Category Management",
      icon: "grid-outline",
      onPress: () => go("/(profile)/category-management"),
    },
    { label: "FAQ", icon: "help-circle-outline", onPress: () => go("/(profile)/faq") },
    { label: "Backup & Restore", icon: "cloud-upload-outline", onPress: () => go("/(profile)/restore-backup") },
    { label: "Export", icon: "download-outline", onPress: () => go("/(profile)/export") },
    { label: "About", icon: "information-circle-outline", onPress: () => go("/(profile)/about") },

  ];

  return (
    <SafeAreaView style={s.screen}>
      <LinearGradient
        colors={["#14162A", BG]}
        start={{ x: 0.2, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={s.bgGlow}
        pointerEvents="none"
      />

      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <ProfileHeader {...user} />
        <BalanceCard {...balance} />

        <TransactionsBreakdown title="Transactions" categories={categories} />
        <SettingsList title="Settings" items={settings} />

        <View style={{ height: NAV_SPACE }} />
      </ScrollView>

      <StreakBadge text="You logged 5 days in a row." bottom={NAV_SPACE - 24} />
      <BottomNav active="profile" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  bgGlow: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 260,
    opacity: 0.9,
  },
  scroll: { paddingHorizontal: H_PADDING, paddingTop: 6, paddingBottom: 0 },
});
