import { Dots } from "@/components/ui/Dots";
import { GhostButton } from "@/components/ui/GhostButton";
import { PrimaryButton } from "@/components/ui/PrimaryButton";
import { router, type Href } from "expo-router";
import { useCallback, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";

import { BackHandler, Image, Pressable, StatusBar, StyleSheet, Text, View } from "react-native";

const BG = "#0D0E13";
const FG = "white";
const MUTED = "#B8BECD";
const SKIP = "#8C93A9";

export default function Step2() {
  const goPrev = useCallback(() => {
    router.replace("/(onboarding)/step1" as Href);
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener("hardwareBackPress", () => { goPrev(); return true; });
    return () => sub.remove();
  }, [goPrev]);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: BG }]}>
      <StatusBar barStyle="light-content" />
      <View style={styles.head}>
        <View />
        <Pressable onPress={() => router.replace("/(auth)/register-email" as Href)}>
          <Text style={{ color: SKIP, fontWeight: "600", letterSpacing: 0.6 }}>SKIP</Text>
        </Pressable>
      </View>

      <View style={styles.hero}>
        <Image
          source={require("@/assets/images/Frame 4064.png")}
          style={{ width: 260, height: 260 }}
          resizeMode="contain"
        />
      </View>

      <View style={styles.bodyWrap}>
        <Text style={[styles.title, { color: FG }]}>Track your spending, the chill way</Text>
        <Text style={[styles.body, { color: MUTED }]}>
          Just speak or type what you spent, like “Spent about 30 on groceries”, and we’ll handle the rest. No stress.
        </Text>
        <Dots active={2} />
      </View>

      <View style={[styles.footer, { flexDirection: "row", gap: 12 }]}>
        <GhostButton label="PREV" onPress={goPrev} />
        <PrimaryButton label="NEXT" onPress={() => router.push("/(onboarding)/step3" as Href)} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, paddingHorizontal: 20 },
  head: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 8 },
  hero: { alignItems: "center", marginTop: 24 },
  bodyWrap: { alignItems: "center", paddingHorizontal: 8, marginTop: 8 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center" },
  body: { fontSize: 14, textAlign: "center", lineHeight: 20, marginTop: 12 },
  footer: { marginTop: "auto", alignItems: "center", marginBottom: 24, alignSelf: "center" },
});
