import { Dots } from "@/components/ui/Dots";
import { GhostButton } from "@/components/ui/GhostButton";
import { PrimaryButton } from "@/components/ui/PrimaryButton";
import { router, type Href } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";

import { BackHandler, Image, Pressable, StatusBar, StyleSheet, Text, View } from "react-native";
// import { setOnboardingSeen } from "@/lib/storage"; // si luego quieres saltártelo

const BG = "#0D0E13";
const FG = "white";
const MUTED = "#B8BECD";
const SKIP = "#8C93A9";

export default function Step3() {
  const [busy, setBusy] = useState(false);

  const goPrev = useCallback(() => {
    router.replace("/(onboarding)/step2" as Href);
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener("hardwareBackPress", () => { goPrev(); return true; });
    return () => sub.remove();
  }, [goPrev]);

  const finish = async () => {
    if (busy) return;
    setBusy(true);
    // await setOnboardingSeen('1');
    router.replace("/(auth)/register-email" as Href);
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: BG }]}>
      <StatusBar barStyle="light-content" />
      <View style={styles.head}>
        <View />
        <Pressable onPress={finish}>
          <Text style={{ color: SKIP, fontWeight: "600", letterSpacing: 0.6 }}>SKIP</Text>
        </Pressable>
      </View>

      <View style={styles.hero}>
        <Image
          source={require("@/assets/images/Invest.png")}
          style={{ width: 260, height: 260 }}
          resizeMode="contain"
        />
      </View>

      <View style={styles.bodyWrap}>
        <Text style={[styles.title, { color: FG }]}>The big picture, without the stress</Text>
        <Text style={[styles.body, { color: MUTED }]}>
          Understand your spending patterns in a way that’s easy to follow and made for real people.
        </Text>
        <Dots active={3} />
      </View>

      <View style={[styles.footer, { flexDirection: "row", gap: 12 }]}>
        <GhostButton label="PREV" onPress={goPrev} />
        <PrimaryButton label="LET’S GET STARTED" onPress={finish} disabled={busy} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, paddingHorizontal: 20 },
  head: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 8 },
  hero: { alignItems: "center", marginTop: 24 },
  bodyWrap: { alignItems: "center", paddingHorizontal: 8, marginTop: 8 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center" },
  body: { fontSize: 14, textAlign: "center", lineHeight: 20, marginTop: 12 },
  footer: { marginTop: "auto", alignItems: "center", marginBottom: 24, alignSelf: "center" },
});
