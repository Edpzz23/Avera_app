import { Dots } from "@/components/ui/Dots";
import { PrimaryButton } from "@/components/ui/PrimaryButton";
import { router, type Href } from "expo-router";
import { Image, Pressable, StatusBar, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const BG = "#0D0E13";
const FG = "white";
const MUTED = "#B8BECD";
const SKIP = "#8C93A9";

export default function Step1() {
  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: BG }]}>
      <StatusBar barStyle="light-content" />
      <View style={styles.head}>
        <View />
        <Pressable onPress={() => router.replace("/(auth)/register-email" as Href)}>
          <Text style={{ color: SKIP, fontWeight: "600", letterSpacing: 0.6 }}>SKIP</Text>
        </Pressable>
      </View>

      <View style={styles.hero}>
        <Image
          source={require("@/assets/images/Frame 4058.png")}
          style={{ width: 260, height: 260 }}
          resizeMode="contain"
        />
      </View>

      <View style={styles.bodyWrap}>
        <Text style={[styles.title, { color: FG }]}>
          Not everyone wants to budget to the penny
        </Text>
        <Text style={[styles.body, { color: MUTED }]}>
          Most of us just want a rough idea of where our money goes. That’s exactly what Average is for.
        </Text>
        <Dots active={1} />
      </View>

      <View style={styles.footer}>
        <PrimaryButton label="NEXT" onPress={() => router.push("/(onboarding)/step2" as Href)} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, paddingHorizontal: 20 },
  head: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 8 },
  hero: { alignItems: "center", marginTop: 24 },
  bodyWrap: { alignItems: "center", paddingHorizontal: 8, marginTop: 8 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center" },
  body: { fontSize: 14, textAlign: "center", lineHeight: 20, marginTop: 12 },
  footer: { marginTop: "auto", alignItems: "center", marginBottom: 24 },
});
