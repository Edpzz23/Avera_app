// app/(onboarding)/select-categories.tsx
import { PrimaryButton } from "@/components/ui/PrimaryButton";
import { router, type Href } from "expo-router";
import { useMemo, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const BG = "#0D0E13";
const FG = "#FFFFFF";
const MUTED = "#B8BECD";
const BORDER = "#2B2F3A";
const ACCENT = "#7A5AF8";

type Item = { key: string; title: string; desc: string };

const CATEGORIES: Item[] = [
  { key: "essentials", title: "The Essentials", desc: "For the minimalist who wants a simple clean slate." },
  { key: "student",    title: "Student Life",   desc: "For tracking campus costs, part-time gigs, and social life." },
  { key: "family",     title: "Family & Home",  desc: "For managing household bills, groceries, and family expenses." },
  { key: "pro",        title: "The Freelancer & Pro", desc: "For tracking business expenses, client income, and subscriptions." },
];

export default function SelectCategories() {
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const hasSelection = selected.size > 0;
  const ctaText = hasSelection ? "LET’S START TRACKING" : "START WITH ALL CATEGORIES";

  const toggle = (k: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(k) ? next.delete(k) : next.add(k);
      return next;
    });
  };

  const goNext = (setToUse?: Set<string>) => {
 // const chosen = Array.from(setToUse ?? selected); // si luego persistes, úsalo
  router.replace("/(tabs)" as Href); // 
  };

  const onCta = () => {
    if (selected.size === 0) {
      const all = new Set(CATEGORIES.map((c) => c.key));
      setSelected(all);
      goNext(all);
    } else {
      goNext();
    }
  };

  const cards = useMemo(() => CATEGORIES, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BG }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>Select Expenses Categories</Text>
        <Text style={styles.subtitle}>
          Lorem ipsum dolor sit amet, nesctetur písicing elit, sed do eiusmod.
        </Text>

        <View style={{ gap: 10, marginTop: 10 }}>
          {cards.map((it) => {
            const active = selected.has(it.key);
            return (
              <Pressable
                key={it.key}
                onPress={() => toggle(it.key)}
                style={[
                  styles.card,
                  active && { borderColor: ACCENT, backgroundColor: "#12162A" },
                ]}
                accessibilityRole="button"
              >
                <View style={{ flex: 1 }}>
                  <Text style={[styles.cardTitle]}>{it.title}</Text>
                  <Text style={styles.cardDesc}>{it.desc}</Text>
                </View>
                <View style={[styles.radio, active && styles.radioActive]}>
                  {active ? <Text style={styles.radioDot}>✓</Text> : null}
                </View>
              </Pressable>
            );
          })}
        </View>

        {/* SOLO CTA, sin botón Prev */}
        <View style={styles.ctaWrap}>
          <PrimaryButton label={ctaText} onPress={onCta} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
  },
  title: { color: FG, fontSize: 20, fontWeight: "800", marginTop: 8 },
  subtitle: { color: MUTED, fontSize: 13, lineHeight: 18, marginTop: 8 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: "#0F1118",
  },
  cardTitle: { color: FG, fontWeight: "700", marginBottom: 4 },
  cardDesc: { color: MUTED, fontSize: 12, lineHeight: 16 },
  radio: {
    width: 22, height: 22, borderRadius: 999,
    borderWidth: 1.5, borderColor: BORDER,
    alignItems: "center", justifyContent: "center",
  },
  radioActive: { borderColor: ACCENT, backgroundColor: ACCENT },
  radioDot: { color: "#0D0E13", fontWeight: "900", fontSize: 12 },
  ctaWrap: { marginTop: 18 },
});
