// constants/theme.ts
import { Platform } from "react-native";

export const AccentColor = "#7FFF00";
export const DarkBackground = "#151718";

/**
 * Paleta base + llaves de tema claro/oscuro.
 * OJO: además de light/dark, exponemos alias de nivel superior
 * (text, background, etc.) para compatibilidad con código que usa Colors.text.
 */
export const Colors = {
  light: {
    text: "#11181C",
    background: "#FFFFFF",
    tint: "#0a7ea4",
    icon: "#687076",
    tabIconDefault: "#687076",
    tabIconSelected: "#0a7ea4",
  },
  dark: {
    text: "#ECEDEE",
    background: DarkBackground,
    tint: AccentColor,
    icon: "#9BA1A6",
    tabIconDefault: "#9BA1A6",
    tabIconSelected: AccentColor,
  },

  // Paleta global propia (no rompe light/dark)
  bg: "#0D0E13",
  fg: "#FFFFFF",
  muted: "#B8BECD",
  border: "#2B2F3A",
  lime: "#C7FF46",
  purple: "#7A5AF8",
  purpleDark: "#2A2141",

  // UI surfaces y estados
  card: "#171A21",
  card2: "#1E2330",
  stroke: "#313849",
  success: "#77DD57",
  danger: "#FF606B",

  /**
   * Aliases de nivel superior para compatibilidad:
   * permiten usar Colors.text / background / tint / icon / tabIcon* directamente.
   * Elegimos por defecto el esquema oscuro para que “encaje” con tus pantallas.
   */
  get text() {
    return this.dark.text;
  },
  get background() {
    return this.dark.background;
  },
  get tint() {
    return this.dark.tint;
  },
  get icon() {
    return this.dark.icon;
  },
  get tabIconDefault() {
    return this.dark.tabIconDefault;
  },
  get tabIconSelected() {
    return this.dark.tabIconSelected;
  },
} as const;

/** Radios disponibles (se añade 'full' como alias de pill) */
export const radii = { sm: 10, md: 12, lg: 14, xl: 20, pill: 999, get full() { return this.pill; } } as const;

/** Sombras reutilizables (se añaden sm/md/lg + purpleGlow existente) */
export const shadow = {
  sm: {
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 2,
    shadowOpacity: 0.12,
    elevation: 2,
  },
  md: {
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    shadowOpacity: 0.18,
    elevation: 6,
  },
  lg: {
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 10 },
    shadowRadius: 20,
    shadowOpacity: 0.22,
    elevation: 12,
  },
  purpleGlow: {
    shadowColor: Colors.purple,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 34,
    shadowOpacity: 0.6,
  },
} as const;

export const Fonts = Platform.select({
  ios: { sans: "system-ui", serif: "ui-serif", rounded: "ui-rounded", mono: "ui-monospace" },
  default: { sans: "normal", serif: "serif", rounded: "normal", mono: "monospace" },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});

export type ColorScheme = "light" | "dark";

/**
 * Theme derivado por modo; si en el futuro quieres alternar dinámicamente,
 * puedes consumir makeTheme(...) en un provider.
 */
export function makeTheme(mode: ColorScheme) {
  const scheme = mode === "dark" ? Colors.dark : Colors.light;

  const bg = mode === "dark" ? "#0B0B0F" : "#FFFFFF";
  const bgAlt = mode === "dark" ? "#111527" : "#F5F7FB";

  return {
    mode,
    colors: {
      ...scheme,
      bg,
      bgAlt,
      textMuted: mode === "dark" ? "#C9D0E1" : "#556071",
      dot: mode === "dark" ? "#444B5D" : "#C7CFDC",
      dotActive: mode === "dark" ? "#9AA9F8" : "#5761C9",
      primary: mode === "dark" ? "#C7FF68" : "#0a7ea4",
      primaryText: mode === "dark" ? "#111111" : "#FFFFFF",
      ghostBg: mode === "dark" ? "#1F2433" : "#E9EEF5",
      ghostText: mode === "dark" ? "#C9D0E1" : "#243042",
      border: mode === "dark" ? "#363E54" : "#D6DEE9",
    },
    radius: { md: 16, lg: 24, xl: 32 },
    spacing: { xs: 6, sm: 10, md: 14, lg: 20, xl: 24 },
    fontSizes: { body: 14, title: 20 },
  };
}
