import { useEffect, useRef } from "react";
import { Animated, Easing } from "react-native";

export function usePulse(active: boolean) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.stopAnimation(); v.setValue(0); return; }
    Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: 1500, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 1500, easing: Easing.in(Easing.quad), useNativeDriver: true }),
    ])).start();
  }, [active]);
  const scale = v.interpolate({ inputRange: [0,1], outputRange: [1,1.08] });
  const glow  = v.interpolate({ inputRange: [0,1], outputRange: [0.25,0.75] });
  return { scale, glow };
}
